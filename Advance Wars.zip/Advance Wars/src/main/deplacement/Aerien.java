package main.deplacement;

public class Aerien extends Deplacement {
	public Aerien() {
		super(
				"Aérien",
				null
		);
	}
}
