package main.terrain;

import ressources.Chemins;

public class Plaine extends Terrain {
	public Plaine() {
		super(Chemins.FICHIER_PLAINE);
	}
}
