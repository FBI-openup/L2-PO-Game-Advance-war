package main.terrain;

import ressources.Chemins;

public class Montagne extends Terrain {
	public Montagne() {
		super(Chemins.FICHIER_MONTAGNE);
	}
}
