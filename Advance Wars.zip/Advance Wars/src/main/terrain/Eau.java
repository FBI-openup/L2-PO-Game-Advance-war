package main.terrain;

import ressources.Chemins;

public class Eau extends Terrain {
	public Eau() {
		super(Chemins.FICHIER_EAU);
	}
}
