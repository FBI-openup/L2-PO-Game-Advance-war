package main.terrain;

import ressources.Chemins;

public class Foret extends Terrain {
	public Foret() {
		super(Chemins.FICHIER_FORET);
	}
}
