package main.terrain;

import ressources.Chemins;

public class QG extends Propriete {
	public QG(int joueurNum) {
		super(
				Chemins.FICHIER_QG,
				joueurNum
		);
	}
}
