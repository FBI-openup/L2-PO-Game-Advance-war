This is the *Advance Wars* project for the class *Programmation Objet*  
Have fun!